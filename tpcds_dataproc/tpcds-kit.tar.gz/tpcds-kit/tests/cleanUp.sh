#!/bin/sh
# $id:$
# $log:$
rm -rf temp_build
rm -rf /data/*.csv
